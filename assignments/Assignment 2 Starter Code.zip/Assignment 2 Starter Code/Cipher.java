public interface Cipher {
	public char encode( char ch);
	public char decode( char ch);
}
